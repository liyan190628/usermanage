import {
    directives
} from './methods'

let apiBaseUrl = require('./ApiConst').apiBaseUrl
apiBaseUrl += 'user/api'

console.log(apiBaseUrl)

// export { }
